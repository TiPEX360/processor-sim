#pragma once
#include "instr.h"

// struct IFID {
//     Instr cir;
//     int npc;
// };

// struct IDEX {
//     int Rd;
//     int Rn;
//     int Ri;
//     int npc;
//     Instr cir;
// };




// struct EXMEM {
//     Instr cir;
//     int out;
//     int Rd;
//     int Rn;
//     int Ri;
// };

// struct MEMWB {

// }